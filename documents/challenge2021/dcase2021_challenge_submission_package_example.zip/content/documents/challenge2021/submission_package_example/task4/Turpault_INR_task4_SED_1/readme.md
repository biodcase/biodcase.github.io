Please follow strictly the format illustrated in `Turpault_INR_task4_SED_1.output_PSDS` directory. In order to comply with the submission platform restrictions, you will need to upload these in separate archive files.

If you experience any problem while submitting PSDS outputs please contact the task organizers (Romain Serizel in priority).
