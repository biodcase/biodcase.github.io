PSDS submissions are optional. **Only the csv files formatted as `Turpault_INR_task4_SS_SED_1.output.csv` are mandatory to participate.**

If you want your system to be evaluated in PSDS please follow strictly the format illustrated in `Turpault_INR_task4_SS_SED_1.output_PSDS`. In order to comply with the submission platform restrictions, you will need to upload these in separate archive files.

If you experience any problem while submitting PSDS outputs please contact the task organizers (Romain Serizel in priority).
