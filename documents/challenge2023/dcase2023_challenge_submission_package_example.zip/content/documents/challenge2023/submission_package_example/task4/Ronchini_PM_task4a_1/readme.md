Please follow strictly the format illustrated in `Ronchini_PM_task4a_1_run1.output_PSDS` directory. In order to comply with the submission platform restrictions, you might need to upload these in separate archive files.

If you experience any problem while submitting PSDS outputs please contact the task organizers (Romain Serizel in priority).
